
/* cookies */
const setCookie = (n, v, d = 365) => document.cookie = `${n}=${v}; Max-Age=${d * 86400}; path=/`;
const getCookie = n => document.cookie.split(';').find(c => c.trim().startsWith(n))?.split('=')[1] || null;
const deleteCookie = n => setCookie(n, '', -1);

/* validação email */
const isEmailValid = e => /^\S+@\S+\.\S+$/.test(e);

/* login */
const form = document.querySelector('form');
if (form) {
  form.addEventListener('submit', e => {
    e.preventDefault();
    const email = document.getElementById('username').value.trim();
    const senha = document.getElementById('password').value;

    if (!email || !isEmailValid(email)) return alert('Email inválido');
    if (senha.length < 6) return alert('Senha mínimo 6 caracteres');

    sessionStorage.setItem('user', JSON.stringify({ email }));
    sessionStorage.email = email;
    window.location.href = 'pagina-logada.html';
  });
}

/* página logada */
if (document.getElementById('welcome')) {
  if (!sessionStorage.email) window.location.href = 'index.html';

  document.getElementById('welcome').textContent = `Bem vindo, ${sessionStorage.email}`;

  const setTheme = t => {
    document.documentElement.classList.toggle('dark', t === 'dark');
    setCookie('theme', t);
  };

  const currentTheme = getCookie('theme') || 'light';
  setTheme(currentTheme);

  document.getElementById('themeLight')?.addEventListener('click', () => setTheme('light'));
  document.getElementById('themeDark')?.addEventListener('click', () => setTheme('dark'));
  document.getElementById('toggleThemeBtn')?.addEventListener('click', () => 
    setTheme(getCookie('theme') === 'dark' ? 'light' : 'dark')
  );
  document.getElementById('logoutBtn')?.addEventListener('click', () => {
    sessionStorage.clear();
    deleteCookie('theme');
    window.location.href = 'index.html';
  });
}